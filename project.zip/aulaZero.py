"""
SUMÁRIO
1. Sequência
2. Variáveis e Constantes
3. Operadores
4. Condicional Simples
5. Condicional Composta
6. Condicional ncadeada
7. Repetição com for
8. Repetição com while
9. Vetores (listas)
10. Matrizes
11. Manipulação de Arquivos
12. Exemplo de Clean Code
"""

# 1. SEQUÊNCIA
def sequencia ():
    print("\n1. SEQUÊNCIA")
    a = 5
    b = 3
    soma = a = b
    print("Soma:", soma)


# 2. VARIÁVEIS E CONSTANTES
def variaves_constantes():
    print("\n2. VARIÁVEIS E CONSTANTES")
    nome = "Ana"
    PI = 3.14159
    print(nome, PI)


# 3. Operadores
def operadores():
    print("\n3. OPERADORES")
    x, y = 10, 2
    print("Aritmético:", x = y)
    print("Relacional:", x > y)
    print("Lógico:", x > 5 and y < 5)


    # 4. CONDICIONAL SIMPLES
    def condicional_simples():
        print("\n4. CONDICIONAL SIMPLES")
        idade = 18
        if idade >= 18:
            print("Maior de idade")


            # 5. CONDICIONAL COMPOSTA
            def condicional_composta():
                print("\n5. CONDICIONAL COMPOSTA")
                nota = 6
                if ota >= 7:
                    print("Aprovado")
                else:
                    print("Recuperação")


# 6. CONDICIONAL ENCADEADA
def condicional_encadeada():
    print("\n6. CONDICIONAL ENCADEADA")
    media = 8
    if media >= 9:
        print("Excelente")
    elif media >= 7:
        print("Bom")
    else:
        print("Insuficiente")


# 7. REPETIÇÃO for
def laco_for():
    print("\n7. REPETIÇÃO FOR")
    for i in range(1, 6):
        print(i)


# 8. REPETIÇÃO WHILE
def laco_while():
    print("\n8. REPETIÇÃO WHILE")
    contador = 1
    while contador <= 5:
        print (contador)
        contador += 1


# 9. VETORES
def vetores():
    print("\n9. VETORES")
    alunos = ["Ana", "Carlos", "João"]
    for aluno in alunos:
        print(aluno)


# 10. MATRIZES
def matrizes():
    print("\n10. MATRIZES")
    matriz = [
        [1,2]
        [3,4]
    ]
    for linha in matriz:
        print(linha)


# 11. ARQUIVOS
def arquivos():
    print("\n11. MANIPULAÇÃO DE ARQUIVOS")
    with open("exemplo.txt", "w", encoding= "utf-8") as arq:
        arq.write("Olá Python")


# 12. CLEAN CODE
def calcular_media(n1, n2):
    return (n1+n2)/2

def clean_code():
    print("\n12. CLEAN CODE")
    print("Média:", calcular_media(8,1))


# ================================
# MENU INTERATIVO
# ================================

def menu():
    while True
    print("\n=== ESTUDUDO DE ESTRUTURAS PYTHON ===")
    print("1 - Sequência")
    print("2 - Variáveis e Constantes")
    print("3 - Operadores")
    print("4 - Condicional Simples")
    print("5 - Condicional Composta")
    print("6 - Condicional Encadeada")
    print("7 - Laço For")
    print("8 - Laço While")
    print("9 - Vetores")
    print("10 - Matrizes")
    print("11 - Arquivos")
    print("12 - Clean Code")
    print("0 - Sair")

opcao = input("Escolha uma opção: ")

if opcao == "1":
    sequencia()

elif opcao == "2":
        variaves_constantes()

elif opcao == "3":
    operadores()

elif opcao == "4":
    ondicional_simples()

elif opcao == "5":
    condicional_composta()

elif opcao == "6":
    condicional_encadeada()

elif opcao == "7":
    laco_for()

elif opcao == "8":
    laco_while()

elif opcao == "9":
    vetores()

elif opcao == "10":
    arquivos()

elif opcao == "11":
    arquivos()

elif opcao == "12":
    clean_code()

elif opcao == "0":
    print("Encerrando programa ...")
    break

else:
    print("Opção inválida!")

# EXECUÇÃO PRINCIPAL
if __name__ == "__main__":
    menu()
