valor_original = float(input("Digite o valor do e-book (R$): "))

if valor_original > 80.00:
    desconto = valor_original * 0.10
    valor_final = valor_original - desconto
    print(f"Valor com desconto de 10%: R$ {valor_final:.2f}")
else:
    print(f"Valor original: R$ {valor_original:.2f}")
