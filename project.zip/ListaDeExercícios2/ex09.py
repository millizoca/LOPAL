percentual_faltas = float(input("Digite o percentual de faltas acumuladas (sem o símbolo %): "))

if percentual_faltas >= 12.5:
    print("Atenção: Limite de ausência atingido")
else:
    print("Frequência regular")
