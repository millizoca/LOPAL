carrinho = []

while True:
  
    item = input("Digite o nome de um item (ou 'sair' para encerrar): ")
    
    if item.lower() == "sair":
        break
        
    carrinho.append(item)

print("\n--- Itens no seu Carrinho de Compras ---")
for item in carrinho:
    print(f"- {item}")
