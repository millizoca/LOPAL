lista_emails = [
    "teste@gmail.com", 
    "admin@escola.br", 
    "usuario@outlook.com", 
    "prof@escola.br", 
    "contato@empresa.com"
]

for email in lista_emails:
    if email.endswith("@escola.br"):
        print(email)
