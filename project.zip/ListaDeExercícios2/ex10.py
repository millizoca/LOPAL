valor_atual = float(input("Digite o valor atual da bolsa do estagiário: R$ "))

if valor_atual < 1000:
    novo_valor = valor_atual * 1.15  # Aplica 15% de aumento
else:
    novo_valor = valor_atual * 1.10  # Aplica 10% de aumento

print(f"O novo valor da bolsa é: R$ {novo_valor:.2f}")
