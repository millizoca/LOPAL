tamanho_mb = float(input("Digite o tamanho do arquivo em Megabytes (MB): "))
velocidade_mbps = float(input("Digite a velocidade da internet em Mbps: "))

tamanho_mbits = tamanho_mb * 8

tempo_segundos = tamanho_mbits / velocidad_mbps

print(f"O tempo aproximado de download é de {tempo_segundos:.2f} segundos.")
