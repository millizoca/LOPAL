valor_reais = float(input("Digite o valor em Reais (R$): "))
cotacao_dolar = float(input("Digite a cotação atual do Dólar (US$): "))

valor_dolares = valor_reais / cotacao_dolar

print(f"O valor convertido é: US$ {valor_dolares:.2f}")
