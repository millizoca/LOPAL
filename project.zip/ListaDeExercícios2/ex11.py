contador = 10

while contador >= 1:
    print(contador)
    contador -= 1  # Subtrai 1 do contador a cada iteração

print("Serviço reiniciado")
