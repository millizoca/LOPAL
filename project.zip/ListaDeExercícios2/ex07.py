primeiro_octeto = int(input("Digite o primeiro octeto do endereço IP: "))

if 1 <= primeiro_octeto <= 126:
    print("Classe A")
elif 128 <= primeiro_octeto <= 191:
    print("Classe B")
elif 192 <= primeiro_octeto <= 223:
    print("Classe C")
else:
    print("Valor fora das faixas especificadas ou octeto inválido (ex: 127).")
