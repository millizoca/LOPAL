ano_nascimento = int(input("Digite o ano de seu nascimento: "))
ano_atual = int(input("Digite o ano atual: "))

idade = ano_atual - ano_nascimento

print(f"Você completou ou completará {idade} anos em {ano_atual}.")
