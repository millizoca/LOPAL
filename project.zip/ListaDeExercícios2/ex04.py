temperatura = float(input("Digite a temperatura atual do servidor (°C): "))

if temperatura > 75:
    print("Alerta: Superaquecimento!")
else:
    print("Temperatura normal.")
