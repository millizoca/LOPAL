# Criação da matriz 3x3
sala = [["L" for _ in range(3)] for _ in range(3)]

print("Mapa de Assentos:")
for linha in sala:
    print(" ".join(linha))
