chamados = ["Erro no login", "Impressora offline", "Troca de senha"]

print(f"Chamados abertos: {chamados}")
concluido = input("Digite o nome do chamado concluído para remover: ")

if concluido in chamados:
    chamados.remove(concluido)
    print(f"Chamado '{concluido}' removido com sucesso!")
else:
    print("Chamado não encontrado.")

print(f"Lista atualizada: {chamados}")