precos = []
for i in range(5):
    preco = float(input(f"Preço do produto {i+1}: R$ "))
    precos.append(preco)

subtotal = sum(precos)
imposto = subtotal * 0.10
valor_final = subtotal + imposto

print(f"\n--- Cupom Fiscal ---")
print(f"Subtotal: R$ {subtotal:.2f}")
print(f"Imposto (10%): R$ {imposto:.2f}")
print(f"Valor Final: R$ {valor_final:.2f}")
