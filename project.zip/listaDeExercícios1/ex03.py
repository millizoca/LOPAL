megabytes = float(input("Digite o valor em megabytes (MB): "))

kilobytes = megabytes * 1024

print(f"{megabytes} MB equivale a {kilobytes} KB")