senha = input("Crie uma senha (mínimo 8 caracteres): ")

while len(senha) < 8:
    print("Erro: A senha deve ter pelo menos 8 caracteres.")
    senha = input("Digite uma senha válida: ")

print("Senha cadastrada com sucesso!")
