pares = 0

for i in range(1, 11):
    num = int(input(f"Digite o {i}º número: "))
    if num % 2 == 0:
        pares += 1

print(f"\nVocê digitou {pares} números pares.")
