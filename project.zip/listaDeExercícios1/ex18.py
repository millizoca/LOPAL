usuarios = []

while True:
    print("\n--- MENU ---")
    print("1 - Cadastrar usuário")
    print("2 - Listar usuários")
    print("3 - Sair")
    
    opcao = input("Escolha uma opção: ")

    if opcao == '1':
        nome = input("Digite o nome do usuário: ")
        usuarios.append(nome)
        print(f"Usuário {nome} cadastrado!")
    
    elif opcao == '2':
        print("\nLista de Usuários:")
        for i, usuario in enumerate(usuarios, 1):
            print(f"{i}. {usuario}")
            
    elif opcao == '3':
        print("Saindo do sistema...")
        break
        
    else:
        print("Opção inválida! Tente novamente.")
