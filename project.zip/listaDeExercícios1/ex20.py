# Lista de vendas
vendas = [150.00, 2300.50, 450.00, 89.90, 1200.00]

# Cálculos
maior_venda = max(vendas)
menor_venda = min(vendas)
total_vendido = sum(vendas)
media = total_vendido / len(vendas)

# Exibição dos resultados
print(f"Maior venda: R$ {maior_venda:.2f}")
print(f"Menor venda: R$ {menor_venda:.2f}")
print(f"Total vendido: R$ {total_vendido:.2f}")
print(f"Média das vendas: R$ {media:.2f}")
