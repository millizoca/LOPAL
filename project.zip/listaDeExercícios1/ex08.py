uso_cpu = 10

while uso_cpu <= 100:
    print(f"{uso_cpu}%")
    uso_cpu += 10
