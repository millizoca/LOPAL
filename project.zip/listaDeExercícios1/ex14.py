usuarios = []

for i in range(5):
    nome = input(f"Digite o nome do usuário {i+1}: ")
    usuarios.append(nome)

print("\nLista de usuários cadastrados:")
for usuario in usuarios:
    print(f"- {usuario}")
