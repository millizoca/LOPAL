usuarios = ["Ana", "Bruno", "Carla", "Daniel", "Eduarda"]

nome_busca = input("Digite o nome que deseja buscar: ")

if nome_busca.capitalize() in usuarios:
    print(f"O usuário '{nome_busca}' foi encontrado no sistema.")
else:
    print(f"O usuário '{nome_busca}' não está cadastrado.")
