desenvolvedores = ["Alice", "Bruno", "Carla", "Diego", "Elena"]

for nome in desenvolvedores:
    print(nome)
